// Smooth redirect delay (optional)
document.querySelector(".access-box").addEventListener("click", function (e) {
  e.preventDefault();
  this.innerText = "Loading...";
  setTimeout(() => {
    window.location.href = this.href;
  }, 500); // half second delay before redirect
});
